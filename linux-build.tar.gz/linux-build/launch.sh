#!/bin/bash

export LD_LIBRARY_PATH=`pwd`/lib
#echo `pwd`/lib
./YouTube-Player